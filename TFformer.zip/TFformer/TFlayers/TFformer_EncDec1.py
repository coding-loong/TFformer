import torch
import torch.nn as nn
from TFlayers.TF_functions import LayerNormalization


class Layernorm(nn.Module):
    """
    Special designed layernorm for the seasonal part
    """
    def __init__(self, channels):
        super(Layernorm, self).__init__()
        self.layernorm = nn.LayerNorm(channels)

    def forward(self, x):
        x_hat = self.layernorm(x)
        bias = torch.mean(x_hat, dim=1).unsqueeze(1).repeat(1, x.shape[1], 1)
        return x_hat - bias

class Encoder(nn.Module):
    """
    Autoformer encoder
    """
    def __init__(self, enc_layers, norm_layer=None):
        super(Encoder, self).__init__()
        self.enc_layers = nn.ModuleList(enc_layers)
        self.norm = norm_layer

    def forward(self, x):
        decomp_list = []
        for enc_layer in self.enc_layers:
            x, decomp = enc_layer(x)
            decomp_list.append(decomp)
        decomp_all = torch.cat(decomp_list,-1)
        # if self.norm is not None:
        #     x = self.norm(x)
        return x, decomp_all


class EncoderLayer(nn.Module):
    """
    Autoformer encoder layer with the progressive decomposition architecture
    """
    def __init__(self, enc_decomp, f_attention, tcn, enc_comp, d_norm,decomp_layers, drop=0.1):
        super(EncoderLayer, self).__init__()

        # Encoder中每一个block的处理流程
        self.decomp = enc_decomp
        self.f_attention = f_attention
        self.tcn = tcn
        self.comp = enc_comp
        self.layer_norm = LayerNormalization(d_norm)
        self.dropout = nn.Dropout(drop)
        self.linear = nn.Linear(in_features=decomp_layers + 1, out_features=1)

    def forward(self, x):
        a = torch.transpose(x, -2, -1)
        b = self.decomp(a, is_decomp=True)
        c = torch.stack(b, dim=2)
        d = self.f_attention(c, c)
        e = self.tcn(d)
        e = self.layer_norm(e)
        f = self.decomp(e, is_decomp=False)
        g = torch.cat(f, dim=1)
        # h = self.linear(g.transpose(-1, -2))
        h = torch.sum(g, dim=1).unsqueeze(-1)
        return h, e


class DecoderInput(nn.Module):
    def __init__(self, dec_embedding, t_attention, linear1, linear2, d_norm, drop=0.1):
        super(DecoderInput, self).__init__()
        self.dec_embedding = dec_embedding
        self.t_attention = t_attention
        self.linear1 = linear1
        self.linear2 = linear2
        self.drop1 = nn.Dropout(drop)
        self.drop2 = nn.Dropout(drop)
        self.layer_norm = LayerNormalization(d_norm)

    def forward(self, x):
        a = self.dec_embedding(x)
        b = self.t_attention(a,a,a)[0]
        c = b.transpose(-1, -2)
        d = self.linear1(c)
        # d = self.drop1(d)
        e = d.transpose(-1, -2)
        f = self.linear2(e)
        # f = self.drop2(f)
        # f = self.layer_norm(f)
        return f


class DecoderInput1(nn.Module):
    def __init__(self, tcn, conv):
        super(DecoderInput1, self).__init__()
        self.tcn = tcn
        self.conv = conv

    def forward(self, x):
        a = x.transpose(-1,-2).unsqueeze(1)
        b = self.tcn(a)
        c = self.conv(b)
        d = c.transpose(-1,-2)[:,0,:,:]
        return d


class Decoder(nn.Module):
    """
    Autoformer encoder
    """
    def __init__(self, layers, norm_layer=None, projection=None):
        super(Decoder, self).__init__()
        self.dec_layers = nn.ModuleList(layers)
        self.norm = norm_layer

    def forward(self, x, cross, x_mask=None, cross_mask=None, trend=None):
        for layer in self.dec_layers:
            x = layer(x, cross, x_mask=x_mask, cross_mask=cross_mask)

        # if self.norm is not None:
        #     x = self.norm(x)

        # if self.projection is not None:
        #     x = self.projection(x)
        return x


class DecoderLayer(nn.Module):
    """
    Autoformer decoder layer with the progressive decomposition architecture
    """
    def __init__(self, dec_decomp,tcn, f_attention, t_attention, dec_comp, d_norm, decomp_layers, drop=0.1):
        super(DecoderLayer, self).__init__()
        self.decomp = dec_decomp
        self.f_attention = f_attention
        self.t_attention = t_attention
        self.tcn = tcn
        self.comp = dec_comp
        self.layer_norm = LayerNormalization(d_norm)
        self.dropout = nn.Dropout(drop)
        self.linear = nn.Linear(in_features=decomp_layers+1, out_features=1)
    def forward(self, x, cross, x_mask=None, cross_mask=None):
        cross = cross[:,0,:,:].transpose(-1,-2)
        a = torch.transpose(x, -2, -1)
        b = self.decomp(a, is_decomp=True)
        c = torch.stack(b, dim=2)
        d = self.f_attention(c, c)[:,0,:,:]
        e = self.t_attention(d.transpose(-1,-2), cross, cross)[0]
        e = e.unsqueeze(1).transpose(-2, -1)
        f = self.tcn(e)
        f = self.layer_norm(f)
        g = self.decomp(f, is_decomp=False)
        h = torch.cat(g, dim=1)
        # i = self.linear(h.transpose(-1,-2))
        i = torch.sum(h, dim=1).unsqueeze(-1)
        return i