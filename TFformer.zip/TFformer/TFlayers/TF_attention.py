import torch
import torch.nn as nn
import torch.nn.init as init
from TFlayers.TF_tcn import TemporalConvNet
import math
import numpy as np


class FrequencyAttention(nn.Module):
    def __init__(self, num_inputs):
        super(FrequencyAttention, self).__init__()

        self.conv_q = nn.Conv2d(in_channels=num_inputs, out_channels=num_inputs, kernel_size=1)
        self.conv_k = nn.Conv2d(in_channels=num_inputs, out_channels=num_inputs, kernel_size=1)
        self.conv_v = nn.Conv2d(in_channels=num_inputs, out_channels=num_inputs, kernel_size=1)

    def forward(self, q, k_v):
        batch, d_model, f_layers, seq_len = q.shape
        # np_q = q.cpu().detach().numpy()
        Q = self.conv_q(q)
        K = self.conv_k(k_v)
        V = self.conv_v(k_v)
        score = torch.einsum("abcd,abed->ace", Q, K)
        # score = torch.matmul(Q,torch.transpose(K,-1,-2))

        score_scale = score/math.sqrt(d_model*seq_len)
        softmax = torch.softmax(score_scale,dim=-1)
        # attention = torch.matmul(softmax, V)
        attention = torch.einsum("ace,abed->abcd", softmax, V)
        # res_out = self.layer_norm(attention + q)
        return attention

class TemporalCrossAttention(nn.Module):
    def __init__(self, num_inputs, seq_len, pred_len, label_len, drop=0.05):
        super(TemporalCrossAttention, self).__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.label_len = label_len

        # self.query_projection = nn.Linear(d_model, d_model)
        # self.key_projection = nn.Linear(d_model, d_model)
        # self.value_projection = nn.Linear(d_model, d_model)
        self.conv_q = nn.Conv1d(in_channels=num_inputs, out_channels=num_inputs, kernel_size=1)
        self.conv_k = nn.Conv1d(in_channels=num_inputs, out_channels=num_inputs, kernel_size=1)
        self.conv_v = nn.Conv1d(in_channels=num_inputs, out_channels=num_inputs, kernel_size=1)
        self.drop = nn.Dropout(drop)

    def forward(self, x, cross):
        x = x.transpose(-1,-2)
        cross = cross.transpose(-1,-2)
        q = self.conv_q(x)
        k = self.conv_k(cross)
        v = self.conv_v(cross)

        zeros1 = torch.zeros_like(x[:, :, :self.label_len]).float()
        k_extend = torch.cat([zeros1, k], dim=-1)
        zeros2 = torch.zeros_like(k).float()
        q_extend = torch.cat([q[:,:,:self.label_len], zeros2], dim=-1)
        q_fft = torch.fft.rfft(q_extend, dim=-1)
        k_fft = torch.fft.rfft(k_extend, dim=-1)
        res = k_fft * torch.conj(q_fft)
        corr = torch.fft.irfft(res, dim=-1)
        v_deal = self.deal_v(v, corr, q)

        out = torch.cat([q[:,:,:self.label_len],v_deal],dim=-1)
        return out.transpose(-1,-2)

    def deal_v(self, v, score, q):
        score_cut = score[:,:,3:self.seq_len-2]
        softmax = torch.softmax(score_cut,dim=-1)
        softmax = self.drop(softmax)
        new_v = 0

        for i in range(3,self.seq_len-2):  # 2-94
            a,b=divmod(self.pred_len,(self.seq_len-i))
            v_cut_roll = [v[:,:,i:] for j in range(a)]+[v[:,:,i:i+b]]
            v_cut_roll = torch.cat(v_cut_roll,dim=-1)
            new_v += torch.mul(v_cut_roll,softmax[:,:,i-3:i-2])
        return new_v


    def deal_v1(self, v, score, q):
        batch, dim, length = score.shape
        score_cut = score[:,:,3:self.seq_len-2]

        weight = torch.linspace(0, 1, steps=self.label_len)[3:]
        weight = weight.unsqueeze(0).unsqueeze(0).repeat(batch, dim, 1).cuda()
        score_cut[...,:self.label_len-3] = torch.mul(score_cut[...,:self.label_len-3],weight)
        softmax = torch.softmax(score_cut,dim=-1)
        softmax = self.drop(softmax)
        new_v = torch.zeros_like(q[:,:,:self.pred_len]).float()
        for i in range(3,self.seq_len-2):  # 2-94
            a,b=divmod(self.pred_len,(self.seq_len-i))
            v_cut_roll = [v[:,:,i:] for j in range(a)]+[v[:,:,i:i+b]]
            v_cut_roll = torch.cat(v_cut_roll,dim=-1)
            new_v += torch.mul(v_cut_roll,softmax[:,:,i-3:i-2])
        return new_v

    def deal_v2(self, v, score, q):
        batch, dim, length = score.shape
        index =get_frequency_modes(self.seq_len)
        init_index = torch.tensor(index).unsqueeze(0).unsqueeze(0).repeat(batch, dim, 1).cuda()
        score_cut = torch.gather(score, dim=-1, index=init_index)
        softmax = torch.softmax(score_cut,dim=-1)
        softmax = self.drop(softmax)
        new_v = torch.zeros_like(q[:,:,:self.pred_len]).float()

        for i, j in enumerate(index):
            a,b=divmod(self.pred_len,(self.seq_len-j))
            v_cut_roll = [v[:,:,j:] for k in range(a)]+[v[:,:,j:j+b]]
            v_cut_roll = torch.cat(v_cut_roll,dim=-1)
            new_v += torch.mul(v_cut_roll,softmax[:,:,i:i+1])
        return new_v


class TemporalAttention1(nn.Module):
    def __init__(self, num_inputs, seq_len, pred_len, label_len, drop=0.05):
        super(TemporalAttention1, self).__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.label_len = label_len
        # self.query_projection = nn.Linear(d_model, d_model)
        # self.key_projection = nn.Linear(d_model, d_model)
        # self.value_projection = nn.Linear(d_model, d_model)
        self.conv_q = nn.Conv2d(in_channels=num_inputs, out_channels=num_inputs, kernel_size=1)
        self.conv_k = nn.Conv2d(in_channels=num_inputs, out_channels=num_inputs, kernel_size=1)
        self.conv_v = nn.Conv2d(in_channels=num_inputs, out_channels=num_inputs, kernel_size=1)
        self.drop = nn.Dropout(drop)

    def forward(self, x, cross, cross_,attn_mask=0):
        x = x.transpose(-1,-2)
        cross = cross.transpose(-1,-2)
        xq = self.conv_q(x)
        xk = self.conv_k(cross)
        xv = self.conv_v(cross)

        zeros1 = torch.zeros_like(xq[..., :self.label_len]).float()
        k_extend = torch.cat([zeros1, xk], dim=-1)
        zeros2 = torch.zeros_like(xk).float()
        q_extend = torch.cat([xq[...,:self.label_len], zeros2], dim=-1)
        q_fft = torch.fft.rfft(q_extend, dim=-1)
        k_fft = torch.fft.rfft(k_extend, dim=-1)
        res = k_fft * torch.conj(q_fft)
        corr = torch.fft.irfft(res, dim=-1)
        v_deal = self.deal_v(xv, corr, xq)
        out = torch.cat([xq[...,:self.label_len],v_deal],dim=-1)
        return (out, None)

    def deal_v(self, v, score, q):
        score_cut = score[...,3:self.seq_len-2]
        softmax = torch.softmax(score_cut,dim=-1)
        softmax = self.drop(softmax)
        new_v = torch.zeros_like(q[...,:self.pred_len]).float()

        for i in range(3,self.seq_len-2):  # 2-94
            a,b=divmod(self.pred_len,(self.seq_len-i))
            v_cut_roll = [v[...,i:] for j in range(a)]+[v[...,i:i+b]]
            v_cut_roll = torch.cat(v_cut_roll,dim=-1)
            new_v += torch.mul(v_cut_roll,softmax[...,i-3:i-2])
        return new_v


    def deal_v1(self, v, score, q):
        batch, dim, length = score.shape
        score_cut = score[:,:,3:self.seq_len-2]

        weight = torch.linspace(0, 1, steps=self.label_len)[3:]
        weight = weight.unsqueeze(0).unsqueeze(0).repeat(batch, dim, 1).cuda()
        score_cut[...,:self.label_len-3] = torch.mul(score_cut[...,:self.label_len-3],weight)
        softmax = torch.softmax(score_cut,dim=-1)
        softmax = self.drop(softmax)
        new_v = torch.zeros_like(q[:,:,:self.pred_len]).float()
        for i in range(3,self.seq_len-2):  # 2-94
            a,b=divmod(self.pred_len,(self.seq_len-i))
            v_cut_roll = [v[:,:,i:] for j in range(a)]+[v[:,:,i:i+b]]
            v_cut_roll = torch.cat(v_cut_roll,dim=-1)
            new_v += torch.mul(v_cut_roll,softmax[:,:,i-3:i-2])
        return new_v

    def deal_v2(self, v, score, q):
        batch, dim, length = score.shape
        index =get_frequency_modes(self.seq_len)
        init_index = torch.tensor(index).unsqueeze(0).unsqueeze(0).repeat(batch, dim, 1).cuda()
        score_cut = torch.gather(score, dim=-1, index=init_index)
        softmax = torch.softmax(score_cut,dim=-1)
        softmax = self.drop(softmax)
        new_v = torch.zeros_like(q[:,:,:self.pred_len]).float()

        for i, j in enumerate(index):
            a,b=divmod(self.pred_len,(self.seq_len-j))
            v_cut_roll = [v[:,:,j:] for k in range(a)]+[v[:,:,j:j+b]]
            v_cut_roll = torch.cat(v_cut_roll,dim=-1)
            new_v += torch.mul(v_cut_roll,softmax[:,:,i:i+1])
        return new_v




def get_frequency_modes(seq_len, modes=64, mode_select_method='random'):
    """
    get modes on frequency domain:
    'random' means sampling randomly;
    'else' means sampling the lowest modes;
    """
    if mode_select_method == 'random':
        index = list(range(seq_len))
        np.random.shuffle(index)
        index = index[:modes]
    else:
        index = list(range(0, modes))
    index.sort()
    return index








class MultiHeadAttention(nn.Module):
    def __init__(self, d_k, d_v, d_model, n_heads, drop=0.1):
        super(MultiHeadAttention, self).__init__()
        self.n_heads = n_heads

        self.d_k = d_k
        self.d_v = d_v
        self.d_model = d_model
        self.n_heads = n_heads

        self.w_q = Linear(d_model, d_k * n_heads)
        self.w_k = Linear(d_model, d_k * n_heads)
        self.w_v = Linear(d_model, d_v * n_heads)


        self.scale_factor = np.sqrt(d_k)
        self.softmax = nn.Softmax(dim=-1)

        self.proj = Linear(n_heads * d_v, d_model)
        self.dropout = nn.Dropout(drop)
        self.layer_norm = LayerNormalization(d_model)

    def forward(self, q, k, v):
        residual = q
        # context: a tensor of shape [b_size x len_q x n_heads * d_v]

        # q: [b_size x len_q x d_model]
        # k: [b_size x len_k x d_model]
        # v: [b_size x len_k x d_model]
        b_size = q.size(0)

        # q_s: [b_size x n_heads x len_q x d_k]
        # k_s: [b_size x n_heads x len_k x d_k]
        # v_s: [b_size x n_heads x len_k x d_v]
        q_s = self.w_q(q).view(b_size, -1, self.n_heads, self.d_k).transpose(1, 2)
        k_s = self.w_k(k).view(b_size, -1, self.n_heads, self.d_k).transpose(1, 2)
        v_s = self.w_v(v).view(b_size, -1, self.n_heads, self.d_v).transpose(1, 2)

        # attn: [b_size x n_heads x len_q x len_k]
        scores = torch.matmul(q_s, k_s.transpose(-1, -2)) / self.scale_factor

        attn = self.dropout(self.softmax(scores))

        # outputs: [b_size x n_heads x len_q x d_v]
        context = torch.matmul(attn, v_s)

        # context: [b_size x len_q x n_heads * d_v]
        context = context.transpose(1, 2).contiguous().view(b_size, -1, self.n_heads * self.d_v)

        # project back to the residual size, outputs: [b_size x len_q x d_model]
        output = self.dropout(self.proj(context))
        return self.layer_norm(residual + output), attn


class Linear(nn.Module):
    def __init__(self, in_features, out_features, bias=True):
        super(Linear, self).__init__()
        self.linear = nn.Linear(in_features, out_features, bias=bias)
        init.xavier_normal_(self.linear.weight)
        init.zeros_(self.linear.bias)

    def forward(self, inputs):
        return self.linear(inputs)


class LayerNormalization(nn.Module):
    def __init__(self, d_hid, eps=1e-6):
        super(LayerNormalization, self).__init__()
        self.gamma = nn.Parameter(torch.ones(d_hid))
        self.beta = nn.Parameter(torch.zeros(d_hid))
        self.eps = eps

    def forward(self, z):
        mean = z.mean(dim=-1, keepdim=True,)
        std = z.std(dim=-1, keepdim=True,)
        ln_out = (z - mean) / (std + self.eps)
        ln_out = self.gamma * ln_out + self.beta

        return ln_out