import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from layers.SelfAttention_Family import FullAttention


class my_Layernorm(nn.Module):
    """
    Special designed layernorm for the seasonal part
    """
    def __init__(self, channels):
        super(my_Layernorm, self).__init__()
        self.layernorm = nn.LayerNorm(channels)

    def forward(self, x):
        x_hat = self.layernorm(x)
        bias = torch.mean(x_hat, dim=1).unsqueeze(1).repeat(1, x.shape[1], 1)
        return x_hat - bias


class EncoderLayer(nn.Module):
    """
    Autoformer encoder layer with the progressive decomposition architecture
    """
    def __init__(self, FrequencyEnhanceLayer, TemporalExtractLayer,configs, dropout=0.1, activation="relu"):
        super(EncoderLayer, self).__init__()
        self.FE = FrequencyEnhanceLayer
        self.TE = TemporalExtractLayer
        self.dropout = nn.Dropout(dropout)
        self.activation = F.relu if activation == "relu" else F.gelu
        self.linear = nn.Sequential(nn.Linear(configs.seq_len, 512, bias=True), nn.LeakyReLU(),
                                    nn.Linear(512, configs.pred_len, bias=True))

    def forward(self, x):
        x_fe, x_trend = self.FE(x)
        x_fe = x + self.dropout(x_fe)
        x_trend = x + self.dropout(x_trend)
        x_te = self.TE(x_fe.transpose(1,2)).transpose(1,2) + x_fe
        x_trend = self.TE(x_trend.transpose(1,2)).transpose(1,2) + x_trend
        x_trend = self.linear(x_trend.transpose(1,2)).transpose(1,2)

        return x_te, x_trend


class Encoder(nn.Module):
    """
    Autoformer encoder
    """
    def __init__(self, attn_layers, norm_layer=None):
        super(Encoder, self).__init__()
        self.attn_layers = nn.ModuleList(attn_layers)
        self.norm = norm_layer
    def forward(self, x):
        trend = 0
        for attn_layer in self.attn_layers:
            x, x_trend = attn_layer(x)
            trend += x_trend
        if self.norm is not None:
            x = self.norm(x)

        return x, trend


class DecoderLayer(nn.Module):
    """
    Autoformer decoder layer with the progressive decomposition architecture
    """
    def __init__(self, FrequencyEnhanceLayer, TemporalExtractLayer, TemporalCrossAttention, TemporalReconstructLayer,
                 d_model, c_out, dropout=0.1, activation="relu"):
        super(DecoderLayer, self).__init__()

        self.FE = FrequencyEnhanceLayer
        self.TE = TemporalExtractLayer
        self.TCA = TemporalCrossAttention
        self.TR = TemporalReconstructLayer



        self.dropout = nn.Dropout(dropout)
        self.projection = nn.Conv1d(in_channels=d_model, out_channels=c_out, kernel_size=3, stride=1, padding=1,
                                    padding_mode='circular', bias=False)
        self.activation = F.relu if activation == "relu" else F.gelu

    def forward(self, x, cross):
        x_fe, x_trend = self.FE(x)
        x_fe = x + self.dropout(x_fe)
        x_te = self.TE(x_fe.transpose(1, 2)).transpose(1, 2) + x_fe
        x_tca = self.TCA(x_te, cross)
        x_tr = self.TR(x_tca.transpose(1, 2)).transpose(1, 2) + x_tca
        return x_tr


class Decoder(nn.Module):
    """
    Autoformer encoder
    """
    def __init__(self, layers, pre_len, norm_layer=None, projection=None):
        super(Decoder, self).__init__()
        self.pre_len = pre_len
        self.layers = nn.ModuleList(layers)
        self.norm = norm_layer
        self.projection = projection

    def forward(self, x, cross, trend):
        for layer in self.layers:
            x = layer(x, cross)

        if self.norm is not None:
            x = self.norm(x)
        x = x[:, -self.pre_len:, :]+trend
        # if self.projection is not None:
        #     x = self.projection(x)
        return x
