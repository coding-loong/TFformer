import torch
import torch.nn as nn
from torch.nn.utils import weight_norm


class FrequencyEnhanceLayer(nn.Module):
    def __init__(self, decomp, fatt):
        super(FrequencyEnhanceLayer, self).__init__()
        self.decomp = decomp
        self.fatt = fatt


    def forward1(self,x):
        a = x.transpose(-2, -1)
        b = self.decomp(a, is_decomp=True)
        c = torch.stack(b, dim=2)
        c1 = c[:,:,:-1,:]
        c2 = c[:,:,-1:,:]
        d = self.fatt(c1, c1)
        e = torch.cat([d,c2], dim=-2)
        f = self.decomp(e, is_decomp=False)
        g = torch.stack(f[:-1], dim=2)
        # h = self.linear(g.transpose(-1, -2))
        h = torch.sum(g, dim=2)

        out = h.transpose(-2, -1)
        return out

    def forward(self, x):
        a = x.transpose(-2, -1)
        b = self.decomp(a, is_decomp=True)
        c = torch.stack(b, dim=2)
        f = self.decomp(c, is_decomp=False)
        g = torch.stack(f[:-1], dim=2)
        g = self.fatt(g,g)
        # h = self.linear(g.transpose(-1, -2))
        h = torch.sum(g, dim=2)
        out = h.transpose(-2, -1)
        return out,f[-1].transpose(-2, -1)

class TemporalExtractLayer(nn.Module):
    def __init__(self, channels, i, model_type='conv'):
        super(TemporalExtractLayer, self).__init__()
        if model_type == 'conv':
            Dilation_size = 2 ** i  # 膨胀系数：1，2，4，8……
            in_channels = channels  # 确定每一层的输入通道数
            out_channels = channels  # 确定每一层的输出通道数
            dropout = 0.2
            Kernel_size = 3
            Stride = 1
            Padding = int((Kernel_size - 1) * Dilation_size/2)
            self.conv1 = weight_norm(nn.Conv1d(in_channels, out_channels, Kernel_size,
                                               stride=Stride, padding=Padding, dilation=Dilation_size))
            self.relu1 = nn.ReLU()
            self.dropout1 = nn.Dropout(dropout)
            self.conv2 = weight_norm(nn.Conv1d(out_channels, out_channels, Kernel_size,
                                               stride=Stride, padding=Padding, dilation=Dilation_size))
            self.relu2 = nn.ReLU()
            self.dropout2 = nn.Dropout(dropout)

            self.net = nn.Sequential(self.conv1,  self.relu1, self.dropout1, self.conv2,  self.relu2, self.dropout2)

    def init_weights(self):
        """
        参数初始化

        :return:
        """
        self.conv1.weight.data.normal_(0, 0.01)
        self.conv2.weight.data.normal_(0, 0.01)
        if self.downsample is not None:
            self.downsample.weight.data.normal_(0, 0.01)

    def forward(self, x):
        out = self.net(x)
        return out

class TemporalReconstructLayer(nn.Module):
    def __init__(self, channels, i, model_type='conv'):
        super(TemporalReconstructLayer, self).__init__()
        if model_type == 'conv':
            Dilation_size = 2 ** i  # 膨胀系数：1，2，4，8……
            in_channels = channels  # 确定每一层的输入通道数
            out_channels = channels  # 确定每一层的输出通道数
            dropout = 0.2
            Kernel_size = 3
            Stride = 1
            Padding = int((Kernel_size - 1) * Dilation_size/2)
            # Lout=(Lin−1)×stride+dilation×(kernel_size−1)+1  −2×padding+output_padding
            self.UpSampling1 = weight_norm(nn.ConvTranspose1d(in_channels, out_channels, Kernel_size,
                                                              stride=Stride, padding=Padding, dilation=Dilation_size))
            self.relu1 = nn.ReLU()
            self.dropout1 = nn.Dropout(dropout)
            self.UpSampling2 = weight_norm(nn.ConvTranspose1d(in_channels, out_channels, Kernel_size,
                                                              stride=Stride, padding=Padding, dilation=Dilation_size))
            self.relu2 = nn.ReLU()
            self.dropout2 = nn.Dropout(dropout)

            self.net = nn.Sequential(self.UpSampling1,  self.relu1, self.dropout1, self.UpSampling2, self.relu2, self.dropout2)
            self.downsample = nn.Conv1d(in_channels, out_channels, 1) if in_channels != out_channels else None


    def init_weights(self):
        """
        参数初始化

        :return:
        """
        self.UpSampling1.weight.data.normal_(0, 0.01)
        self.UpSampling2.weight.data.normal_(0, 0.01)
        if self.downsample is not None:
            self.downsample.weight.data.normal_(0, 0.01)

    def forward(self, x):
        out = self.net(x)
        return out
