import numpy as np
import torch
import torch.nn as nn
from torch.nn.utils import weight_norm
import math
import pywt

import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False
def plot_e2e(data, n, rec_a, rec_d):
    fig = plt.figure()
    for i in range(n + 2):
        if i == 0:
            plt.subplot(n + 2, 1, i + 1)
            plt.plot(data, label='原数据曲线')
            plt.legend(loc='best')
        elif i == 1:
            plt.subplot(n + 2, 1, i + 1)
            a = rec_a[-1]
            plt.plot(a, 'g', label='数据曲线趋势')
            plt.legend(loc='best')
        else:
            plt.subplot(n + 2, 1, i + 1)
            b = rec_d[i - 2]
            plt.plot(b, 'r', label='数据曲线噪声%d' % (i + 1 - 2))
            plt.legend(loc='best')
    fig.suptitle("端对端小波图")
    plt.tight_layout()
    plt.show()


class MoDwt(nn.Module):
    def __init__(self, data_length, wavelet_type, dec_layers):
        super(MoDwt, self).__init__()
        self.input_length = int(data_length)
        self.wavelet_type = wavelet_type
        self.dec_layers = int(dec_layers)
        self.modwt_net = self.get_modwt_net()

    def get_modwt_net(self):
        modwt_net = nn.ModuleList()
        # 从原始数据中分解出h1,h2,...,hn,ln的分量权重存储在modwt_net中
        for i in range(self.dec_layers):
            modwt_h_i = nn.Linear(self.input_length, self.input_length, bias=False)  # 分解第i次的高频分量
            modwt_h_i.weight = nn.Parameter(self.get_modwt_w(level=i + 1, is_l=False))
            modwt_h_i.requires_grad_(False)
            modwt_net.append(modwt_h_i)
        modwt_l_i = nn.Linear(self.input_length, self.input_length, bias=False)  # 分解最后一次的低频分量
        modwt_l_i.weight = nn.Parameter(self.get_modwt_w(level=self.dec_layers, is_l=True))
        modwt_l_i.requires_grad_(False)
        modwt_net.append(modwt_l_i)
        return modwt_net

    def get_modwt_w(self, level, is_l):
        '''
        x:序列
        filter_type：小波基类型
        level：选择分解的层数
        is_l: 是否是低通滤波
        '''
        dwt_filter_i = self.get_filter(level, is_l=is_l)
        dwt_filter_i = np.array(dwt_filter_i) / (2 ** (level / 2))
        dwt_filter_length = len(dwt_filter_i)  # 滤波器宽度
        n = int(self.input_length / dwt_filter_length)
        filter_i = None
        # 处理第i层滤波器
        if n == 0:  # 第i层滤波器长度大于输入数据长度进行截断
            filter_i = dwt_filter_i[0:self.input_length]
        elif n > 0:  # 第i层滤波器长度不大于输入数据长度进行补零
            filter_i = np.concatenate([dwt_filter_i, np.zeros(self.input_length-dwt_filter_length)], axis=0)  # 填充0
        filter_i_flip = filter_i[::-1]  # 将处理后的滤波器翻转
        # 构建第i层滤波器矩阵
        filter_i_weight_matrix = np.zeros((self.input_length, self.input_length))
        for k in range(0, self.input_length):
            filter_i_weight_matrix[k] = np.roll(filter_i_flip, k + 1)
        return torch.tensor(filter_i_weight_matrix, dtype=torch.float32)

    def get_filter(self, level_j, is_l):
        '''
            计算equivalent filter
            h:小波原来的系数
            j：分解的层数
            最后长度为：
            '''
        filter = pywt.Wavelet(self.wavelet_type)
        filter_hi = filter.dec_hi
        filter_lo = filter.dec_lo
        filters_list = []
        l = len(filter_hi)  # 滤波器宽度
        # filter_lo_i为第j层调整后的滤波器
        for i in range(level_j - 1):
            filter_lo_i = [0 for _ in range((l - 1) * int(math.pow(2, i)) + 1)]
            for temp in range(l):
                filter_lo_i[int(math.pow(2, i) * temp)] = filter_lo[temp]
            filters_list.append(filter_lo_i)

        filter_ = filter_lo if is_l else filter_hi
        filter_j = [0 for _ in range((l - 1) * int(math.pow(2, level_j - 1)) + 1)]
        for temp in range(l):
            filter_j[int(math.pow(2, level_j - 1) * temp)] = filter_[temp]
        filters_list.append(filter_j)

        f_conv = filters_list[0]
        for i in range(1, level_j):
            f_conv = np.convolve(f_conv, filters_list[i])
        return f_conv

    def forward(self, data_input, is_decomp=True):
        wavecoeff = []
        if is_decomp:
            for i in range(self.dec_layers):
                w = self.modwt_net[i](data_input)
                # w_ = (w @ self.modwt_net[i].weight)
                wavecoeff.append(w)
            v = self.modwt_net[-1](data_input)
            # v_ = (v @ self.modwt_net[-1].weight)
            wavecoeff.append(v)
        else:
            for i in range(self.dec_layers):
                w = data_input[:,:,i,:]
                w_ = (w @ self.modwt_net[i].weight)
                wavecoeff.append(w_)
            v = data_input[:,:,-1,:]
            v_ = (v @ self.modwt_net[-1].weight)
            wavecoeff.append(v_)
        return wavecoeff


if __name__ == '__main__':
    """注意序列的长度和filter的长度，太短会不一样"""
    data = torch.randn(96*2).reshape(2, -1)
    MoDwt_obj = MoDwt(data.shape[-1], 'db2', 4)
    ws = MoDwt_obj(data)
    w1 = [_.detach().numpy() for _ in ws]
    w2 = np.array(w1).swapaxes(1, 0)
    t = np.sum(w2, axis=1)
    print(w2)