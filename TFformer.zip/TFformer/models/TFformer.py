import torch
import torch.nn as nn
from layers.Embed import DataEmbedding, DataEmbedding_wo_pos
from TFlayers.TFformer_EncDec import Encoder, Decoder, EncoderLayer, DecoderLayer, my_Layernorm
from TFlayers.TF_wavelet import MoDwt
from TFlayers.TF_attention import FrequencyAttention, TemporalCrossAttention, TemporalAttention1
from TFlayers.TF_correlation import FrequencyEnhanceLayer, TemporalExtractLayer, TemporalReconstructLayer
import torch.nn.functional as F


class Model(nn.Module):
    """
    Autoformer is the first method to achieve the series-wise connection,
    with inherent O(LlogL) complexity
    """
    def __init__(self, configs):
        super(Model, self).__init__()
        self.version = configs.version
        self.mode_select = configs.mode_select
        self.modes = configs.modes
        self.seq_len = configs.seq_len
        self.label_len = configs.label_len
        self.pred_len = configs.pred_len
        self.output_attention = configs.output_attention



        self.enc_embedding = DataEmbedding_wo_pos(configs.enc_in, configs.d_model, configs.embed, configs.freq,
                                                  configs.dropout)
        self.dec_embedding = DataEmbedding_wo_pos(configs.dec_in, configs.d_model, configs.embed, configs.freq,
                                                  configs.dropout)



        # Encoder
        self.encoder = Encoder(
            [
                EncoderLayer(
                    FrequencyEnhanceLayer(  # TF
                        MoDwt(configs.seq_len, configs.wavelet_type, configs.decomp_layers),
                        FrequencyAttention(configs.d_model),

                    ),
                    TemporalExtractLayer(configs.d_model,l),
                    configs,
                    dropout=configs.dropout,
                    activation=configs.activation
                ) for l in range(configs.e_layers)
            ],
            norm_layer=my_Layernorm(configs.d_model)
        )


        # Decoder
        self.decoder = Decoder(
            [
                DecoderLayer(
                    FrequencyEnhanceLayer(  # TF
                        MoDwt(configs.label_len, configs.wavelet_type, configs.decomp_layers),
                        FrequencyAttention(configs.d_model),

                    ),
                    TemporalExtractLayer(configs.d_model, l),
                    TemporalCrossAttention(configs.d_model, configs.seq_len, configs.pred_len, configs.label_len,
                                           drop=configs.dropout),
                    TemporalReconstructLayer(configs.d_model, l),
                    configs.d_model,
                    configs.c_out,
                    dropout=configs.dropout,
                    activation=configs.activation,

                ) for l in range(configs.d_layers)
            ],
            configs.pred_len,
            norm_layer=my_Layernorm(configs.d_model),
            projection=nn.Linear(configs.d_model, configs.c_out, bias=True)
        )

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec,
                enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):
        # decomp init
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(
            torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        # enc

        #enc_out = self.enc_embedding(x_enc, x_mark_enc)
        enc_out, trend = self.encoder(x_enc)
        # dec
        #dec_out = self.dec_embedding(x_enc[:,-self.label_len:,:], x_mark_dec[:,-self.label_len:,:])
        dec_out = self.decoder(x_enc[:,-self.label_len:,:], enc_out, trend)
        # final
        #dec_out = trend_part + seasonal_part

        dec_out = dec_out*stdev+means
        if self.output_attention:
            return dec_out[:, -self.pred_len:, :]
        else:
            return dec_out  # [B, L, D]


